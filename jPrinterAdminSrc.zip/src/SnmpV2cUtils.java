/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package getPrinterData;

/**
 *
 * @author stefan
 */
public class SnmpV2cUtils {
}
