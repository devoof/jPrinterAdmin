/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.jbs.snmputils;

/**
 *
 * @author stefan
 */
class SnmpV1Utils {
}
